# Selenium-Architecture
This project is a sample for Selenium Architecture

I have used a testing site for this project.
Site-URL: http://demo.guru99.com/v4/index.php

After going to this site, you have to re-generate the access time to time (better to re-generate it after every 1 week).
This is mandatory. Otherwise the code will not run as the password provided within the "**/Configuration/config.properties"** file and 
in the "**/com.inetbanking.testData.loginData.xlsx"** file will not match.
Yes, after regenerating the password, you have go to the above 2 files and provide the re-generated password.
